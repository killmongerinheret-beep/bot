'use client';

import { useState, useEffect } from 'react';
import { api } from '@/lib/api';
import { Loader2, Globe, ChevronDown } from 'lucide-react';

interface Ticket {
    id: string;
    name: string;
    needsLanguage: boolean;
    availableLanguages: string[];
    ticketType: number;
}

interface TicketSelectorProps {
    date: string;
    selectedTicketId: string | null;
    selectedTicketName: string | null;
    selectedLanguage: string | null;
    onSelectTicket: (ticketId: string, ticketName: string) => void;
    onSelectLanguage: (language: string | null) => void;
}

export default function TicketSelector({
    date,
    selectedTicketId,
    selectedLanguage,
    onSelectTicket,
    onSelectLanguage
}: TicketSelectorProps) {
    const [tickets, setTickets] = useState<Ticket[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const fetchTickets = async () => {
            if (!date) {
                setLoading(false);
                return;
            }

            try {
                setLoading(true);
                setError(null);
                const data = await api.getVaticanTickets(date);
                setTickets(data.tickets || []);
            } catch (err) {
                console.error('Failed to fetch tickets:', err);
                setError('Failed to load tickets. Please try again.');
            } finally {
                setLoading(false);
            }
        };

        fetchTickets();
    }, [date]);

    if (!date) {
        return (
            <div className="p-4 bg-[#1a1a1a] rounded-xl border border-[#262626]">
                <p className="text-sm text-[#888888]">Please select a date first to view available tickets.</p>
            </div>
        );
    }

    if (loading) {
        return (
            <div className="p-6 bg-[#1a1a1a] rounded-xl border border-[#262626] flex items-center justify-center gap-3">
                <Loader2 className="w-5 h-5 animate-spin text-[#00E37C]" />
                <span className="text-sm text-[#888888]">Loading tickets for {date}...</span>
            </div>
        );
    }

    if (error) {
        return (
            <div className="p-4 bg-[#FF4D4D]/10 rounded-xl border border-[#FF4D4D]/20">
                <p className="text-sm text-[#FF4D4D]">{error}</p>
            </div>
        );
    }

    if (tickets.length === 0) {
        return (
            <div className="p-4 bg-orange-500/10 rounded-xl border border-orange-500/20">
                <p className="text-sm text-orange-400">No tickets found for {date}. Try a different date.</p>
            </div>
        );
    }

    return (
        <div className="space-y-4">
            <div className="flex items-center gap-2 mb-3">
                <Globe className="w-4 h-4 text-[#888888]" />
                <label className="text-sm font-medium text-white">
                    Select Ticket ({tickets.length} available)
                </label>
            </div>

            <div className="space-y-2 max-h-[300px] overflow-y-auto pr-2">
                {tickets.map((ticket) => {
                    const isSelected = selectedTicketId === ticket.id;

                    return (
                        <div
                            key={ticket.id}
                            className={`
                border rounded-xl p-4 transition-all duration-200 cursor-pointer
                ${isSelected
                                    ? 'border-[#00E37C] bg-[#00E37C]/10'
                                    : 'border-[#262626] bg-[#1a1a1a] hover:border-[#404040]'
                                }
              `}
                            onClick={() => {
                                onSelectTicket(ticket.id, ticket.name);
                                if (!ticket.needsLanguage) {
                                    onSelectLanguage(null);
                                }
                            }}
                        >
                            <div className="flex items-start gap-3">
                                <input
                                    type="radio"
                                    name="ticket"
                                    value={ticket.id}
                                    checked={isSelected}
                                    onChange={() => { }}
                                    className="mt-1 w-4 h-4 accent-[#00E37C]"
                                />

                                <div className="flex-1">
                                    <div className="font-medium text-white text-sm">
                                        {ticket.name}
                                    </div>

                                    <div className="flex items-center gap-2 mt-2">
                                        <span className={`
                      text-xs px-2 py-0.5 rounded-full font-medium
                      ${ticket.ticketType === 0
                                                ? 'bg-[#00E37C]/20 text-[#00E37C]'
                                                : 'bg-purple-500/20 text-purple-400'
                                            }
                    `}>
                                            {ticket.ticketType === 0 ? 'Standard' : 'Guided Tour'}
                                        </span>

                                        {ticket.needsLanguage && (
                                            <span className="text-xs text-[#888888]">
                                                • Requires language
                                            </span>
                                        )}
                                    </div>
                                </div>
                            </div>

                            {/* Language selector */}
                            {isSelected && ticket.needsLanguage && (
                                <div className="mt-4 ml-7 pl-4 border-l-2 border-[#00E37C]/30">
                                    <label className="block text-xs font-medium text-[#888888] mb-2">
                                        🌐 Tour Language
                                    </label>

                                    <div className="relative">
                                        <select
                                            value={selectedLanguage || ''}
                                            onChange={(e) => onSelectLanguage(e.target.value || null)}
                                            onClick={(e) => e.stopPropagation()}
                                            className="w-full px-3 py-2 pr-8 bg-[#262626] border border-[#404040] rounded-lg text-sm text-white focus:outline-none focus:border-[#00E37C] appearance-none cursor-pointer"
                                        >
                                            <option value="">-- Choose Language --</option>
                                            {ticket.availableLanguages.map((lang) => {
                                                const langNames: Record<string, string> = {
                                                    'ENG': '🇬🇧 English',
                                                    'ITA': '🇮🇹 Italian',
                                                    'FRA': '🇫🇷 French',
                                                    'DEU': '🇩🇪 German',
                                                    'SPA': '🇪🇸 Spanish'
                                                };

                                                return (
                                                    <option key={lang} value={lang}>
                                                        {langNames[lang] || lang}
                                                    </option>
                                                );
                                            })}
                                        </select>

                                        <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#888888] pointer-events-none" />
                                    </div>
                                </div>
                            )}
                        </div>
                    );
                })}
            </div>
        </div>
    );
}
