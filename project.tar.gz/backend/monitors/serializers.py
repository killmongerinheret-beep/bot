from rest_framework import serializers
from .models import Agency, MonitorTask, CheckResult, Proxy, SiteCredential

class SiteCredentialSerializer(serializers.ModelSerializer):
    class Meta:
        model = SiteCredential
        fields = '__all__'

class ProxySerializer(serializers.ModelSerializer):
    class Meta:
        model = Proxy
        fields = '__all__'

class AgencySerializer(serializers.ModelSerializer):
    credentials = SiteCredentialSerializer(many=True, read_only=True)
    class Meta:
        model = Agency
        fields = ['id', 'name', 'api_key', 'telegram_chat_id', 'credentials', 'created_at']

class MonitorTaskSerializer(serializers.ModelSerializer):
    agency_name = serializers.ReadOnlyField(source='agency.name')
    
    class Meta:
        model = MonitorTask
        fields = '__all__'

class CheckResultSerializer(serializers.ModelSerializer):
    class Meta:
        model = CheckResult
        fields = '__all__'
