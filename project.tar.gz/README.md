# 🎫 Ticket Monitor Pro

Professional-grade ticket availability monitor for Vatican Museums and Colosseum with OctoFence bypass capabilities.

## ✨ Features

- **🏛️ Dual Site Support**: Monitor both Vatican Museums and Colosseum
- **🔓 OctoFence Bypass**: Advanced solver for Colosseum anti-bot protection
- **📱 Mobile-Friendly UI**: Responsive Streamlit dashboard
- **🔐 Secure**: Password-protected interface
- **📊 Analytics**: Dashboard metrics and activity logging
- **💬 Real-time Alerts**: Telegram notifications
- **🐳 Docker Ready**: Easy deployment with Docker Compose

---

## 🚀 Quick Start

### Prerequisites

- Python 3.10+
- Node.js 16+ (for OctoFence solver)
- Docker & Docker Compose (for deployment)

### Local Setup

1. **Clone the repository**
   ```bash
   git clone YOUR_REPO_URL
   cd travelagentbot
   ```

2. **Install dependencies**
   ```bash
   # Python dependencies
   python -m venv venv
   source venv/bin/activate  # Windows: .\venv\Scripts\activate
   pip install -r requirements.txt
   playwright install chromium
   
   # Node.js dependencies (for OctoFence solver)
   cd octofence_solver
   npm install
   cd ..
   ```

3. **Configure**
   ```bash
   cp config.sample.json config.json
   # Edit config.json with your Telegram credentials
   ```

4. **Run**
   ```bash
   # UI
   streamlit run app.py
   
   # Engine (in separate terminal)
   python engine.py
   ```

5. **Access UI**
   - Open http://localhost:8501
   - Default password: `admin123`
   - ⚠️ **Change password immediately!**

---

## 🐳 Docker Deployment

### Quick Deploy

```bash
docker-compose up -d
```

Access UI at `http://YOUR_SERVER_IP:8501`

### Configuration

Edit `config.json`:
```json
{
  "telegram_token": "YOUR_BOT_TOKEN",
  "telegram_chat_id": "YOUR_CHAT_ID",
  "interval_min": 2,
  "headless": true
}
```

---

## 🔐 Security

### Change Default Password

1. Generate new password hash:
   ```python
   import hashlib
   password = "your_new_password"
   print(hashlib.sha256(password.encode()).hexdigest())
   ```

2. Update `.streamlit/secrets.toml`:
   ```toml
   password_hash = "YOUR_NEW_HASH"
   ```

### Firewall (Recommended)

```bash
# Hetzner/VPS
ufw allow 22    # SSH
ufw allow 8501  # Streamlit
ufw enable
```

---

## 📖 How It Works

### Vatican Museums
```
Monitor → Playwright → Website → Parse HTML → Find Tickets → Notify
```
- Uses Playwright for browser automation
- Headless Chrome with stealth plugins
- Checks official Vatican ticketing site

### Colosseum (Advanced)
```
Monitor → requests → OctoFence Challenge → Node.js Solver → Generate Cookies → Retry → Parse → Notify
```
- Uses `requests` library (less detectable)
- Solves OctoFence anti-bot challenges
- Node.js solver generates authentication cookies
- More resistant to blocking

---

## 🎯 Usage

### Add a Monitor

1. Go to "Add New Monitor" tab
2. Select site (Vatican/Colosseum)
3. Choose dates and time
4. Click "Add Monitor"

### View Activity

- Dashboard shows real-time stats
- Activity log tracks all checks
- Export/import tasks for backup

---

## 🌐 Deployment Options

| Platform | Cost | Best For |
|----------|------|----------|
| **Hetzner VPS** | €4/mo | Recommended, reliable |
| **Oracle Free Tier** | Free | Budget option |
| **Railway** | Free tier | Easy deploy |
| **Your PC** | Electricity | Testing only |

See [HETZNER_DEPLOYMENT.md](HETZNER_DEPLOYMENT.md) for detailed guide.

---

## 🔧 Advanced Configuration

### Proxies (Optional)

For high-frequency monitoring or if blocked:

```json
{
  "proxy": {
    "server": "http://proxy:port",
    "username": "user",
    "password": "pass"
  }
}
```

**Recommended Providers:**
- Proxy-Cheap (residential, $5/GB)
- IPRoyal (residential, $7/GB)
- Bright Data (premium, $15/GB)

### Multiple Engines

For parallel monitoring, duplicate docker services in `docker-compose.yml`.

---

## 📁 Project Structure

```
travelagentbot/
├── app.py                   # Streamlit UI (optimized)
├── auth.py                  # Authentication module
├── utils.py                 # Utility functions
├── engine.py                # Monitor engine
├── monitor.py               # Vatican monitor
├── monitor_colosseum.py     # Colosseum monitor (with solver)
├── notifications.py         # Telegram notifications
├── octofence_solver/        # OctoFence challenge solver
│   ├── solver/
│   │   ├── main.js
│   │   └── helpers/
│   └── package.json
├── .streamlit/
│   └── secrets.toml         # Authentication secrets
├── docker-compose.yml       # Docker orchestration
├── Dockerfile               # Container definition
├── requirements.txt         # Python dependencies
└── README.md               # This file
```

---

## 🐛 Troubleshooting

### OctoFence Still Blocking

1. Add residential proxies
2. Increase interval between checks
3. Check `activity_log.json` for patterns

### Vatican Monitor Not Working

1. Check Playwright installation: `playwright install chromium`
2. Verify headless mode works
3. Try with `headless: false` for debugging

### Can't Login to UI

1. Verify `.streamlit/secrets.toml` exists
2. Check password hash is correct
3. Clear browser cache

---

## 🤝 Contributing

Feel free to submit issues and PRs for improvements!

---

## ⚠️ Legal Disclaimer

This tool is for educational purposes and personal use only. Always comply with website Terms of Service. Ticket scalping may be illegal in some jurisdictions.

---

## 📞 Support

For deployment help, see `HETZNER_DEPLOYMENT.md`

---

## 📝 License

MIT License - See LICENSE file

---

**✅ Ready for production deployment!**
