from rest_framework import viewsets, permissions, status
from rest_framework.views import APIView
from rest_framework.response import Response
from .models import Agency, MonitorTask, CheckResult, Proxy, SiteCredential
from .serializers import (
    AgencySerializer, MonitorTaskSerializer, CheckResultSerializer,
    ProxySerializer, SiteCredentialSerializer
)

class AgencyViewSet(viewsets.ModelViewSet):
    queryset = Agency.objects.all()
    serializer_class = AgencySerializer
    permission_classes = [permissions.AllowAny]

class MonitorTaskViewSet(viewsets.ModelViewSet):
    serializer_class = MonitorTaskSerializer
    permission_classes = [permissions.AllowAny]

    def get_queryset(self):
        queryset = MonitorTask.objects.all()
        agency_id = self.request.query_params.get('agency_id')
        if agency_id:
            queryset = queryset.filter(agency_id=agency_id)
        return queryset

    def perform_create(self, serializer):
        agency = serializer.validated_data['agency']
        plan = getattr(agency, 'plan', 'free')
        active_task_count = MonitorTask.objects.filter(agency=agency, is_active=True).count()
        
        limits = {
            'free': 2,
            'pro': 20,
            'agency': 500
        }
        limit = limits.get(plan, 2)
        
        if active_task_count >= limit:
            from rest_framework.exceptions import ValidationError
            raise ValidationError({'detail': f"Monitor limit reached for your '{plan}' plan ({limit} tasks). Please upgrade."})
            
        serializer.save()

class CheckResultViewSet(viewsets.ModelViewSet):
    serializer_class = CheckResultSerializer
    permission_classes = [permissions.AllowAny]

    def get_queryset(self):
        queryset = CheckResult.objects.all().order_by('-check_time')
        agency_id = self.request.query_params.get('agency_id')
        task_id = self.request.query_params.get('task')
        
        if task_id:
            queryset = queryset.filter(task_id=task_id)
        if agency_id:
            queryset = queryset.filter(task__agency_id=agency_id)
        return queryset

class ProxyViewSet(viewsets.ModelViewSet):
    queryset = Proxy.objects.all()
    serializer_class = ProxySerializer
    permission_classes = [permissions.AllowAny]

class SiteCredentialViewSet(viewsets.ModelViewSet):
    queryset = SiteCredential.objects.all()
    serializer_class = SiteCredentialSerializer
    permission_classes = [permissions.AllowAny]

class AgencyLoginView(APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        name = request.data.get('name')
        api_key = request.data.get('api_key')
        
        if not name or not api_key:
            return Response({'error': 'Name and API Key search required'}, status=status.HTTP_400_BAD_REQUEST)
            
        agency = Agency.objects.filter(name=name, api_key=api_key).order_by('id').first()
        
        if not agency:
            return Response({'error': 'Invalid credentials'}, status=status.HTTP_401_UNAUTHORIZED)
            
        if not agency.is_active:
            return Response({'error': 'Agency account is inactive'}, status=status.HTTP_403_FORBIDDEN)
            
        return Response({
            'id': agency.id,
            'name': agency.name,
            'chat_id': agency.telegram_chat_id
        })

class MyAgencyView(APIView):
    """
    Get or Create an Agency for the authenticated Clerk User.
    Expects 'owner_id' in request data.
    """
    permission_classes = [permissions.AllowAny] # In future, verify JWT

    def post(self, request):
        owner_id = request.data.get('owner_id')
        email = request.data.get('email', 'Unknown')
        
        if not owner_id:
            return Response({'error': 'owner_id required'}, status=status.HTTP_400_BAD_REQUEST)
            
        # Robust Get or Create to prevent Race Conditions
        import uuid
        defaults = {
            'name': f"Agency-{email.split('@')[0]}",
            'api_key': str(uuid.uuid4())[:8]
        }
        
        agency, created = Agency.objects.get_or_create(
            owner_id=owner_id,
            defaults=defaults
        )
            
        return Response({
            'id': agency.id,
            'name': agency.name,
            'api_key': agency.api_key,
            'chat_id': agency.telegram_chat_id,
            'plan': agency.plan,
            'task_limit': {'free': 2, 'pro': 20, 'agency': 500}.get(agency.plan, 2)
        })


# ✅ NEW: Vatican Ticket Discovery API
from rest_framework.decorators import api_view

@api_view(['GET'])
def get_vatican_tickets(request):
    """
    Returns list of available Vatican tickets with their IDs and language requirements.
    Dynamically fetches from Vatican website using HydraBot.
    
    Query params:
        date: DD/MM/YYYY format (default: 20/02/2026)
    
    Returns:
        {
            'date': '20/02/2026',
            'tickets': [
                {
                    'id': '929041748',
                    'name': 'Musei Vaticani - Biglietti d\'ingresso',
                    'needsLanguage': False,
                    'availableLanguages': [],
                    'ticketType': 0  # 0=Standard, 1=Guided
                },
                ...
            ]
        }
    """
    date = request.query_params.get('date', '20/02/2026')
    
    try:
        from worker_vatican.hydra_monitor import HydraBot
        import asyncio
        import logging
        
        logger = logging.getLogger(__name__)
        logger.info(f"🎫 Fetching Vatican tickets for {date}...")
        
        async def fetch_tickets():
            bot = HydraBot()
            result = []
            
            try:
                async with bot.get_browser() as browser:
                    page = await browser.new_page()
                    
                    # Get Standard Tickets (Tag 1)
                    try:
                        standard_tickets = await bot.resolve_all_dynamic_ids(
                            page,
                            ticket_type=0,  # Standard
                            target_date=date,
                            visitors=2
                        )
                        
                        for ticket in standard_tickets:
                            result.append({
                                'id': ticket['id'],
                                'name': ticket['name'],
                                'needsLanguage': False,
                                'availableLanguages': [],
                                'ticketType': 0,
                                'deepLink': ticket.get('deep_link', '')
                            })
                        
                        logger.info(f"✅ Found {len(standard_tickets)} standard tickets")
                    except Exception as e:
                        logger.error(f"Failed to fetch standard tickets: {e}")
                    
                    # Get Guided Tours (Tag 2)
                    try:
                        guided_tickets = await bot.resolve_all_dynamic_ids(
                            page,
                            ticket_type=1,  # Guided
                            target_date=date,
                            visitors=2
                        )
                        
                        for ticket in guided_tickets:
                            result.append({
                                'id': ticket['id'],
                                'name': ticket['name'],
                                'needsLanguage': True,
                                'availableLanguages': ['ENG', 'ITA', 'FRA', 'DEU', 'SPA'],
                                'ticketType': 1,
                                'deepLink': ticket.get('deep_link', '')
                            })
                        
                        logger.info(f"✅ Found {len(guided_tickets)} guided tours")
                    except Exception as e:
                        logger.error(f"Failed to fetch guided tours: {e}")
                    
                    await page.close()
            
            except Exception as e:
                logger.error(f"Browser error: {e}")
                raise
            
            return result
        
        tickets = asyncio.run(fetch_tickets())
        
        return Response({
            'date': date,
            'tickets': tickets,
            'total': len(tickets)
        })
    
    except Exception as e:
        import traceback
        return Response({
            'error': str(e),
            'traceback': traceback.format_exc()
        }, status=500)
