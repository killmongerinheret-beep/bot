'use client';

import { useState, useEffect } from 'react';
import { MonitorTask, api } from '@/lib/api';
import { motion } from 'framer-motion';
import {
    Clock,
    Calendar,
    Play,
    Trash2,
    ExternalLink
} from 'lucide-react';

interface TaskCardProps {
    task: MonitorTask;
    onDelete?: (id: number) => Promise<void>;
}

export default function TaskCard({ task, onDelete }: TaskCardProps) {
    const [timeLeft, setTimeLeft] = useState<string>('...');

    // Status colors
    const getStatusColor = (status: string) => {
        switch (status?.toLowerCase()) {
            case 'available': return 'bg-[#00E37C]';
            case 'sold_out': return 'bg-[#FF4D4D]';
            case 'closed': return 'bg-[#888888]';
            case 'error': return 'bg-orange-500';
            default: return 'bg-blue-500';
        }
    };

    const getStatusBadgeStyle = (status: string) => {
        switch (status?.toLowerCase()) {
            case 'available':
                return 'bg-[#00E37C]/10 text-[#00E37C] border-[#00E37C]/20';
            case 'sold_out':
                return 'bg-[#FF4D4D]/10 text-[#FF4D4D] border-[#FF4D4D]/20';
            case 'closed':
                return 'bg-[#888888]/10 text-[#888888] border-[#888888]/20';
            case 'error':
                return 'bg-orange-500/10 text-orange-500 border-orange-500/20';
            default:
                return 'bg-blue-500/10 text-blue-400 border-blue-500/20';
        }
    };

    // Countdown logic
    useEffect(() => {
        const interval = setInterval(() => {
            if (!task.last_checked) {
                setTimeLeft('Pending');
                return;
            }
            const lastDate = new Date(task.last_checked);
            const checkInt = task.check_interval || 60;
            const nextDate = new Date(lastDate.getTime() + checkInt * 1000);
            const now = new Date();
            const diff = nextDate.getTime() - now.getTime();

            if (diff <= 0) {
                setTimeLeft('Now');
            } else {
                const mins = Math.floor(diff / 60000);
                const secs = Math.floor((diff % 60000) / 1000);
                setTimeLeft(`${mins}:${secs < 10 ? '0' : ''}${secs}`);
            }
        }, 1000);
        return () => clearInterval(interval);
    }, [task.last_checked, task.check_interval]);

    return (
        <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            whileHover={{ y: -2, transition: { duration: 0.2 } }}
            className="bento-card group"
        >
            {/* Status Bar */}
            <div className={`h-1 w-full -mt-8 -mx-8 mb-6 ${getStatusColor(task.last_status || 'checking')}`}
                style={{ width: 'calc(100% + 64px)' }} />

            {/* Header */}
            <div className="flex justify-between items-start mb-6">
                <div>
                    <h3 className="text-lg font-semibold text-white mb-1">{task.area_name}</h3>
                    <p className="text-xs text-[#888888] uppercase tracking-wider">
                        {task.site === 'vatican' ? 'Vatican Museums' : 'Colosseum'}
                    </p>
                </div>
                <span className={`px-3 py-1 rounded-full text-[10px] font-semibold uppercase tracking-wider border ${getStatusBadgeStyle(task.last_status || 'checking')}`}>
                    {task.last_status?.replace('_', ' ') || 'Pending'}
                </span>
            </div>

            {/* Dates */}
            <div className="mb-6">
                <div className="flex items-center gap-2 text-[#888888] text-xs mb-3">
                    <Calendar className="w-3.5 h-3.5" />
                    <span className="uppercase tracking-wider font-medium">Target Dates</span>
                </div>
                <div className="flex flex-wrap gap-2">
                    {task.dates.slice(0, 4).map((d, i) => (
                        <span
                            key={i}
                            className="bg-[#1a1a1a] border border-[#262626] text-[#888888] px-3 py-1.5 rounded-lg text-xs font-mono"
                        >
                            {d}
                        </span>
                    ))}
                    {task.dates.length > 4 && (
                        <span className="bg-[#1a1a1a] border border-[#262626] text-[#888888] px-3 py-1.5 rounded-lg text-xs">
                            +{task.dates.length - 4} more
                        </span>
                    )}
                </div>
            </div>

            {/* Footer */}
            <div className="flex justify-between items-center pt-4 border-t border-[#262626]">
                <div className="flex items-center gap-2 text-xs text-[#888888]">
                    <div className={`w-2 h-2 rounded-full ${timeLeft === 'Now' ? 'bg-[#00E37C] animate-pulse' : 'bg-[#888888]'}`} />
                    <Clock className="w-3 h-3" />
                    <span className="font-mono text-white">{timeLeft}</span>
                </div>

                <div className="flex gap-2">
                    <button
                        onClick={() => window.location.href = '/dashboard/logs'}
                        className="h-8 px-3 rounded-lg bg-[#1a1a1a] border border-[#262626] text-[#888888] text-xs font-medium hover:text-white hover:border-[#404040] transition-colors"
                    >
                        History
                    </button>
                    <button className="h-8 w-8 rounded-lg bg-[#00E37C] text-[#050505] flex items-center justify-center hover:bg-[#00E37C]/80 transition-colors">
                        <Play className="w-3 h-3 ml-0.5" />
                    </button>
                    <button
                        onClick={async () => {
                            if (confirm('Delete this task?')) {
                                if (onDelete) await onDelete(task.id);
                            }
                        }}
                        className="h-8 w-8 rounded-lg bg-[#FF4D4D]/10 border border-[#FF4D4D]/20 text-[#FF4D4D] flex items-center justify-center hover:bg-[#FF4D4D]/20 transition-colors"
                    >
                        <Trash2 className="w-3 h-3" />
                    </button>
                </div>
            </div>
        </motion.div>
    );
}
