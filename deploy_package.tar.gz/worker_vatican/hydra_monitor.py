import asyncio
import random
import logging
import json
import os
from playwright.async_api import async_playwright

# --- CONFIGURATION ---
# Default targets if not overridden by env vars
DEFAULT_DATES = [
    "26/01/2026", "27/01/2026", "28/01/2026", "29/01/2026", "30/01/2026",
    # Add more dates as needed...
]

# Known IDs
# Known IDs
GUIDED_TOUR_ID = "1602099201" # Will be resolved dynamically
STANDARD_TICKET_ID = "1015200310"     # Standard admission (Verified Jan 2026)
LANGUAGES = ["ENG", "ITA", "FRA", "DEU", "ESP"]

# Configure Logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(message)s')
logger = logging.getLogger("HydraBot")

class HydraBot:
    def __init__(self, use_proxies=True):
        self.use_proxies = use_proxies
        self.proxies = self._load_proxies() if use_proxies else []
        self.target_dates = DEFAULT_DATES  # Can be updated to read from ENV

    def _load_proxies(self):
        """Loads proxies from project root or parent directories (robust path finding)"""
        proxies = []
        try:
            current_dir = os.path.dirname(os.path.abspath(__file__))
            
            # Possible locations for Proxy lists.json
            # 1. 2 levels up (Docker /app)
            path_2_up = os.path.dirname(os.path.dirname(current_dir))
            # 2. 3 levels up (Local Project Root)
            path_3_up = os.path.dirname(os.path.dirname(os.path.dirname(current_dir)))
            # 3. 4 levels up (Just in case)
            path_4_up = os.path.dirname(path_3_up)

            search_paths = [path_2_up, path_3_up, path_4_up, "/app", "/root/travelagentbot"]
            
            base_dir = None
            for p in search_paths:
                # We prioritize the Webshare file now
                json_p = os.path.join(p, "Webshare_10_proxies.txt")
                if os.path.exists(json_p):
                    base_dir = p
                    logger.info(f"📂 Found Webshare proxies at {p}")
                    break
            
            if not base_dir:
                 # Fallback search for original JSON if text file missing
                 for p in search_paths:
                    if os.path.exists(os.path.join(p, "Proxy lists.json")):
                        base_dir = p
                        break
                 if not base_dir:
                    base_dir = path_3_up 
                    logger.warning("⚠️ Could not find proxy files, defaulting to 3 levels up")

            # 1. Webshare proxies (PRIORITY - Because Oxylabs are Firewall Blocked)
            # Correct filename: Webshare_10_proxies.txt (underscores)
            txt_path = os.path.join(base_dir, "Webshare_10_proxies.txt")
            # 1. Load from Proxy lists.json (Oxylabs Shared ISP - High Quality)
            # Confirmed working with abiilesh_2uVXW
            json_path = os.path.join(base_dir, "Proxy lists.json")
            if os.path.exists(json_path):
                with open(json_path, 'r') as f:
                    data = json.load(f)
                    for p in data:
                        # entryPoint is 'isp.oxylabs.io'
                        proxies.append(f"{p['entryPoint']}:{p['port']}") 
                logger.info(f"✅ Loaded {len(proxies)} Oxylabs proxies (Primary)")

            # 2. Webshare proxies (Backup)
            txt_path = os.path.join(base_dir, "Webshare_10_proxies.txt")
            if not proxies and os.path.exists(txt_path):
                 with open(txt_path, 'r') as f:
                     for line in f:
                         if line.strip() and ":" in line:
                             proxies.append(line.strip())
                 logger.info(f"✅ Loaded {len(proxies)} Webshare proxies (Backup)")
                            
            logger.info(f"✅ Loaded {len(proxies)} proxies from {base_dir}")
        except Exception as e:
            logger.error(f"⚠️ Error loading proxies: {e}")
            
        return proxies

    def get_random_proxy(self):
        if not self.proxies:
            return None
        
        p_str = random.choice(self.proxies)
        # Handle different formats
        parts = p_str.split(':')
        
        # Oxylabs format: entryPoint:port (needs username/password from env)
        if len(parts) == 2:
            # Check if this is Oxylabs (isp.oxylabs.io)
            if 'oxylabs' in p_str.lower():
                # Get credentials (Hardcoded based on verification)
                username = "abiilesh_2uVXW"
                password = "Me=billions777"
                
                # Shared ISP Proxies usually don't support "session-id" parameter in username
                # They are static ports.
                # So we just use raw auth.
                
                return {
                    "server": f"http://{p_str}",
                    "username": username,
                    "password": password
                }
            else:
                return {"server": f"http://{p_str}"}
        
        # Webshare format: ip:port:user:pass
        elif len(parts) == 4:
            return {
                "server": f"http://{parts[0]}:{parts[1]}",
                "username": parts[2],
                "password": parts[3]
            }
        
        return None

    async def apply_stealth(self, context, page):
        """Manually apply stealth scripts to context and page"""
        # 1. Remove webdriver
        await context.add_init_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")
        # 2. Mock Chrome
        await context.add_init_script("window.chrome = { runtime: {} };")
        # 3. Mock Permissions (Notification check often reveals bots)
        await context.add_init_script("""
        const originalQuery = window.navigator.permissions.query;
        window.navigator.permissions.query = (parameters) => (
            parameters.name === 'notifications' ?
            Promise.resolve({ state: 'denied' }) :
            originalQuery(parameters)
        );
        """)
        
        # 4. Canvas Noise (Ghost Browser Feature)
        await context.add_init_script("""
        const toBlob = HTMLCanvasElement.prototype.toBlob;
        const toDataURL = HTMLCanvasElement.prototype.toDataURL;
        const getImageData = CanvasRenderingContext2D.prototype.getImageData;
        
        var noise = {
            "r": Math.floor(Math.random() * 10) - 5,
            "g": Math.floor(Math.random() * 10) - 5,
            "b": Math.floor(Math.random() * 10) - 5,
            "a": Math.floor(Math.random() * 10) - 5
        };
        
        // Overwrite toDataURL
        HTMLCanvasElement.prototype.toDataURL = function() {
            const ctx = this.getContext("2d");
            if (ctx) {
                const w = this.width;
                const h = this.height;
                const iData = ctx.getImageData(0, 0, w, h);
                for (let i = 0; i < h; i++) {
                    for (let j = 0; j < w; j++) {
                        const index = ((i * (w * 4)) + (j * 4));
                        iData.data[index] = iData.data[index] + noise.r;
                        iData.data[index+1] = iData.data[index+1] + noise.g;
                        iData.data[index+2] = iData.data[index+2] + noise.b;
                        iData.data[index+3] = iData.data[index+3] + noise.a;
                    }
                }
                ctx.putImageData(iData, 0, 0);
            }
            return toDataURL.apply(this, arguments);
        }
        """)

        # 5. Resource Blocking (Aggressive Speed)
        await page.route("**/*", lambda route: route.abort() 
            if route.request.resource_type in ["image", "media", "font", "stylesheet"] 
            else route.continue_())

    async def fetch_api_ninja(self, page, ticket_id, date, lang_code=None):
        """
        Executes fetch() INSIDE the browser context.
        This inherits all the browser's cookies, TLS fingerprints, and headers automatically.
        """
        lang_param = f"&visitLang={lang_code}" if lang_code else ""
        
        js_code = f"""
        async () => {{
            const url = "https://tickets.museivaticani.va/api/visit/timeavail?lang=it{lang_param}&visitTypeId={ticket_id}&visitorNum=2&visitDate={date}";
            try {{
                const response = await fetch(url, {{
                    "headers": {{ 
                        "accept": "application/json, text/plain, */*", 
                        "x-requested-with": "XMLHttpRequest"
                    }},
                    "method": "GET"
                }});
                if (response.status !== 200) {{
                     return {{ "error": "HTTP " + response.status }};
                }}
                return await response.json();
            }} catch (e) {{ 
                return {{ "error": e.toString() }}; 
            }}
        }}
        """
        return await page.evaluate(js_code)

    async def process_results(self, label, date, data):
        """Analyzes the JSON result from the browser"""
        if "timetable" in data:
            # Filter non-sold-out
            available = [t['time'] for t in data['timetable'] if t['availability'] != 'SOLD_OUT']
            
            if available:
                logger.info(f"✅ {label} [{date}]: FOUND {len(available)} SLOTS! -> {available}")
                # TODO: Trigger Notifications/Telegram here
                if any("16:30" in t for t in available): 
                     logger.info(f"🎯 SNIPER HIT: 16:30 available for {label} on {date}!")
            else:
                pass
        elif "error" in data:
            logger.warning(f"⚠️ API Error ({label} - {date}): {data['error']}")
            
    async def resolve_id_by_tag(self, page, tag="MV-Visite-Guidate"):
        """
        Dynamically finds the Tour ID for a given tag.
        """
        logger.info(f"🔍 Resolving ID for tag: {tag}...")
        js_code = f"""
        async () => {{
            try {{
                const response = await fetch(
                    "https://tickets.museivaticani.va/api/search/resultPerTag?lang=it&visitorNum=2&visitDate={self.target_dates[0]}&volumeId=1&tag={tag}",
                    {{ "headers": {{ "accept": "application/json" }}, "method": "GET" }}
                );
                return await response.json();
            }} catch (e) {{ return {{ "error": e.toString() }}; }}
        }}
        """
        data = await page.evaluate(js_code)
        
        if "visits" in data:
             for visit in data["visits"]:
                 if visit.get("availability") != "SOLD_OUT":
                     gid = visit.get("id")
                     logger.info(f"✅ Resolved {tag} -> ID: {gid}")
                     return str(gid)
                 
             if data["visits"]:
                 gid = data["visits"][0].get("id")
                 logger.info(f"⚠️ All Sold Out, but using ID: {gid}")
                 return str(gid)
                 
        logger.warning(f"❌ Could not resolve ID for {tag}. Using fallback.")
        return None

    async def check_standard_ticket_ui(self, page, date):
        """
        Implements the User's explicit UI logic for Standard Tickets.
        Flow: Date -> Visitors -> Confirm -> Prenota (Ticket 0) -> Check Slots
        """
        try:
            logger.info(f"🖱️ UI CHECK: Standard Ticket for {date}...")
            
            # Format Date: "28/01/2026" -> "January 28," (approximate matching)
            # We need to be careful with Locale. The page usually follows the browser locale.
            # We set locale="en-US" or "it-IT" in context? Code below sets "it-IT".
            # If "it-IT", date would be "28 gennaio".
            # User snippet said: name: 'January 28,' -> This implies English locale!
            # START FIX: The container runs with "it-IT" locale in original code? 
            # Original code: locale="it-IT".
            # If user wants "January 28", we must ensure page is in English or we translate.
            # SAFE BET: The button usually has the DAY NUMBER clearly. 
            # Let's try to match by Day Number and Month if possible, OR assume user meant English.
            # Let's switch context to 'en-US' to match the snippet? 
            # Or just adapt the selector to be robust. 
            
            # User snippet: await page.getByRole('button', { name: 'January 28,' }).click();
            
            # Parsing the input date
            # DB format is usually "YYYY-MM-DD" (e.g. 2026-01-28)
            # User snippet implied "28/01/2026"
            # Let's handle both
            if "-" in date:
                year, month, day = date.split('-')
            else:
                day, month, year = date.split('/')
            
            # Navigate to generic "Biglietti" page or assume we are on a list
            # We need to start from a clean state or specific URL
            await page.goto("https://tickets.museivaticani.va/home", timeout=60000, wait_until="domcontentloaded")
            
            # RATE LIMITING: Add delay to appear human
            await page.wait_for_timeout(random.randint(1500, 3000))
            
            # Select Date
            # The calendar might need opening.
            # Assuming the user snippet runs on the DATE SELECTION step of the flow.
            # We need to click "Biglietti" first to get there?
            # Let's try direct URL to "Biglietti" DATE SELECTOR if possible.
            # URL: https://tickets.museivaticani.va/home/calendar/visit/Biglietti-Musei-Vaticani-e-Cappella-Sistina/1
            
            await page.goto("https://tickets.museivaticani.va/home/calendar/visit/Biglietti-Musei-Vaticani-e-Cappella-Sistina/1", timeout=60000, wait_until="networkidle")
            
            # RATE LIMITING: Wait for page to fully render
            await page.wait_for_timeout(random.randint(2000, 4000))
            
            # Handling Date Selection
            # The calendar is likely displayed. match the date.
            # Note: User snippet uses English text. We will try to execute that exact logic.
            # But we must be sure the month is visible.
            
            # Quick hack: Force English language
            await page.goto(page.url + "?lang=en", timeout=10000)
            
            # RATE LIMITING: Small delay after language change
            await page.wait_for_timeout(random.randint(1000, 2000))
            
            # DEBUG: Screenshot initial state
            os.makedirs("/app/screenshots", exist_ok=True)
            await page.screenshot(path=f"/app/screenshots/debug_{day}_step1_cal.png")
            logger.info(f"📸 Debug Screenshot saved: debug_{day}_step1_cal.png")

            # Convert to datetime for month comparison
            from datetime import datetime
            # Use the already split variables to avoid format issues
            dt = datetime(int(year), int(month), int(day))
            date_str = dt.strftime("%B %d").replace(" 0", " ") # January 28
            
            # Check if we need to navigate to a different month
            from datetime import datetime as dt_now
            current_month = dt_now.now().month
            target_month = int(month)
            
            # If target month is greater than current month, we need to click forward arrows
            months_ahead = target_month - current_month
            if months_ahead < 0:
                # Handle year wrap (e.g., December -> January next year)
                months_ahead += 12
            
            logger.info(f"📅 Target date: {date_str} ({months_ahead} months ahead)")
            
            # Navigate forward through months if needed
            if months_ahead > 0:
                for i in range(months_ahead):
                    try:
                        # Click the right arrow button to go to next month
                        arrow_btn = page.get_by_role('button').filter(has_text="keyboard_arrow_right")
                        await arrow_btn.click(timeout=3000)
                        await page.wait_for_timeout(1000)  # Wait for calendar to update
                        logger.info(f"➡️ Navigated forward {i+1} month(s)")
                    except Exception as e:
                        logger.warning(f"⚠️ Failed to navigate to month {i+1}: {e}")
                        break
            
            logger.info(f"🖱️ Attempting to click date: '{date_str}'")

            # Try user's selector
            try:
                # DEBUG: Log all buttons to see what we have
                buttons_text = await page.evaluate("() => Array.from(document.querySelectorAll('button')).map(b => b.textContent.trim()).join(' | ')")
                logger.info(f"🔘 VISIBLE BUTTONS: {buttons_text[:1000]}...")
                
                # First try exact "January 28"
                await page.get_by_role('button', name=date_str).click(timeout=3000)
                logger.info(f"✅ Clicked Date Button: {date_str}")
                await page.screenshot(path=f"/app/screenshots/debug_{day}_step2_clicked.png")
            except:
                logger.warning(f"⚠️ Could not click exact date '{date_str}', trying robust fallback...")
                
                # Fallback: Find any button with the DAY number.
                try:
                     # Nuclear Option: JS Click
                    was_clicked = await page.evaluate(f"""() => {{
                        const query = "{int(day)}";
                        // Broad search: Any element with text exactly matching the day
                        const allElems = Array.from(document.querySelectorAll('div, span, button, a'));
                        const dayElem = allElems.find(el => {{
                            return el.textContent.trim() === query && el.offsetParent !== null; // Visible
                        }});
                        
                        if (dayElem) {{
                            dayElem.click();
                            return "Clicked generic element for " + query;
                        }}
                        
                        // Try Partial match on Buttons
                        const buttons = Array.from(document.querySelectorAll('button'));
                        const dayBtn = buttons.find(b => {{
                             const t = b.textContent.trim();
                             return t.startsWith(query + ' ') || t === query;
                        }});
                        
                        if (dayBtn) {{
                            dayBtn.click();
                            return "Clicked button for " + query;
                        }}
                        return false;
                    }}""")
                    
                    if was_clicked:
                        logger.info(f"✅ Fallback JS Result: {was_clicked}")
                        await page.wait_for_timeout(1000)
                        await page.screenshot(path=f"/app/screenshots/debug_{day}_step2_fallback_clicked.png")
                    else:
                        raise Exception("JS could not find any element for day")
                        
                except Exception as e_fallback:
                    logger.error(f"❌ Fallback Date Click Failed: {e_fallback}")
                    await page.screenshot(path=f"/app/screenshots/debug_{day}_error_click.png")


            # Visitors
            logger.info("⏳ Waiting for #numberInput...")
            try:
                # Wait for the input to appear (it might be hidden initially)
                await page.locator('#numberInput').wait_for(state="visible", timeout=10000)
                await page.screenshot(path=f"/app/screenshots/debug_{day}_step3_visitors.png")
                await page.locator('#numberInput').click()
                await page.locator('#numberInput').fill('2')
            except Exception as e_vis:
                 logger.error(f"❌ Failed to find/click #numberInput: {e_vis}")
                 await page.screenshot(path=f"/app/screenshots/debug_{day}_error_visitors.png")
                 # Dump HTML to see what's wrong (e.g. maybe date didn't select?)
                 html = await page.content()
                 with open(f"/app/screenshots/debug_{day}_error.html", "w") as f:
                     f.write(html)
                 raise e_vis

            # Handle CONFIRM vs CONFERMA
            # It might be a small popup or modal
            try:
                await page.get_by_role('button', name='CONFIRM').click(timeout=3000)
            except:
                try:
                    await page.get_by_role('button', name='CONFERMA').click(timeout=3000)
                except:
                    logger.warning("⚠️ Could not find CONFIRM/CONFERMA button, maybe auto-advanced?")
            
            # Prenota/Book
            logger.info("🖱️ Clicking PRENOTA...")
            await page.locator('#ticket_dx_0').get_by_role('button').click(timeout=5000)
            
            # Check Results Page
            await page.wait_for_load_state("networkidle")
            await page.screenshot(path=f"/app/screenshots/debug_{day}_step4_results.png")
            
            # Scrape Slots Logic
            available_slots = []
            
            logger.info("📋 Analyzing results page for time slots...")
            
            # Helper to scrape visible times
            async def scrape_visible_times(label):
                found_times = []
                # 1. Get all text from ENABLED button elements (most likely slots)
                # We specifically check for visibility and enabled state
                slots_data = await page.evaluate("""() => {
                    const buttons = Array.from(document.querySelectorAll('button, .time-slot, .slot-item'));
                    return buttons.map(b => ({
                        text: b.textContent.trim(),
                        disabled: b.disabled || b.getAttribute('aria-disabled') === 'true' || b.classList.contains('disabled'),
                        visible: !!(b.offsetWidth || b.offsetHeight || b.getClientRects().length)
                    }));
                }""")
                
                import re
                time_pattern = re.compile(r'^(\d{1,2}:\d{2})$')
                
                for item in slots_data:
                    text = item['text']
                    if time_pattern.match(text):
                        if item['visible'] and not item['disabled']:
                            found_times.append(text)
                        else:
                            logger.info(f"🚫 Ignoring slot {text} (Visible: {item['visible']}, Disabled: {item['disabled']})")
                
                logger.info(f"🔎 {label}: Found {len(found_times)} valid ENABLED time slots: {found_times[:5]}")
                return found_times

            # 1. Check MATTINA / MORNING
            # User snippet: locator('div').filter({ hasText: /^POMERIGGIO$/ }).click()
            # We try to click these tabs to reveal slots
            
            # Try Morning first
            try:
                morning_btn = page.locator('div').filter(has_text=re.compile(r"^(MATTINA|MORNING)$", re.IGNORECASE))
                count = await morning_btn.count()
                logger.info(f"🔍 Found {count} MATTINA buttons")
                
                if count > 0:
                    # Wait for visibility
                    await morning_btn.first.wait_for(state="visible", timeout=3000)
                    logger.info("🖱️ Clicking MATTINA tab...")
                    await morning_btn.first.click()
                    await page.wait_for_timeout(random.randint(1000, 2000))
                    times = await scrape_visible_times("MATTINA")
                    available_slots.extend(times)
            except Exception as e:
                logger.warning(f"⚠️ MATTINA tab click failed: {e}")
            
            # 2. Check POMERIGGIO / AFTERNOON  
            try:
                pomeriggio_btn = page.locator('div').filter(has_text=re.compile(r"^(POMERIGGIO|AFTERNOON)$", re.IGNORECASE))
                count = await pomeriggio_btn.count()
                logger.info(f"🔍 Found {count} POMERIGGIO buttons")
                
                if count > 0:
                    await pomeriggio_btn.first.wait_for(state="visible", timeout=3000)
                    logger.info("🖱️ Clicking POMERIGGIO tab...")
                    await pomeriggio_btn.first.click()
                    await page.wait_for_timeout(random.randint(1000, 2000))
                    times = await scrape_visible_times("POMERIGGIO")
                    available_slots.extend(times)
            except Exception as e:
                logger.warning(f"⚠️ POMERIGGIO tab click failed: {e}")

            # Deduplicate
            available_slots = list(set(available_slots))
            
            if available_slots:
                 logger.info(f"✅ SLOT FOUND via UI Check: {available_slots}")
                 # Convert to Standard Format
                 return [{"time": t, "availability": "AVAILABLE_UI"} for t in available_slots]

            # Fallback: If tabs didn't work, just scrape ALL visible times
            logger.info("⚠️ Fallback: Scraping all visible times without tab navigation...")
            all_times = await scrape_visible_times("FALLBACK")
            if all_times:
                logger.info(f"✅ FALLBACK FOUND SLOTS: {all_times}")
                return [{"time": t, "availability": "AVAILABLE_UI"} for t in all_times]
            
            logger.info("❌ No Slots found (Sold Out view?)")
            return []
            
            
        except Exception as e:
            logger.error(f"UI Check Failed: {e}")
            await page.screenshot(path=f"/app/screenshots/debug_error_final.png")
            return []

    def get_vatican_timestamp(self, date_str):
        """
        Calculates the Vatican Midnight Timestamp (ms) for Deep Linking.
        Uses explicit Europe/Rome timezone via zoneinfo.
        """
        try:
            from zoneinfo import ZoneInfo
            from datetime import datetime
            
            rome = ZoneInfo("Europe/Rome")
            # Handle both YYYY-MM-DD and DD/MM/YYYY
            if "/" in date_str:
                dt = datetime.strptime(date_str, "%d/%m/%Y")
            else:
                dt = datetime.strptime(date_str, "%Y-%m-%d")
                
            midnight = dt.replace(hour=0, minute=0, second=0, microsecond=0, tzinfo=rome)
            return int(midnight.timestamp() * 1000)
        except Exception as e:
            logger.error(f"Timestamp calc failed: {e}")
            return 0 # Should probably fallback or error

    async def resolve_dynamic_id(self, page, ticket_type, target_date):
        """
        Navigates to the Deep Link to establish a valid session and extract the Dynamic `visitTypeId`.
        Crucial for bypassing 500 Errors and "Session Invalid" checks.
        """
        try:
            # 1. Determine Tag & Visitor Config
            # Standard = MV-Biglietti
            # Guided = MV-Visite-Guidate (User provided)
            tag = "MV-Biglietti" if ticket_type == 0 else "MV-Visite-Guidate"
            
            # calculate timestamp for the date
            ts = self.get_vatican_timestamp(target_date)
            # URL: /home/fromtag/1/{TIMESTAMP}/{TAG}/1
            deep_url = f"https://tickets.museivaticani.va/home/fromtag/1/{ts}/{tag}/1"
            
            logger.info(f"🕸️ Navigating to Deep Link: {deep_url}")
            
            # Navigate with valid timeout
            await page.goto(deep_url, timeout=30000, wait_until="domcontentloaded")
            # Wait for content to render (Crucial for extracting ID)
            await page.wait_for_timeout(3000) 
            
            # 2. Extract ID from DOM
            # Look for button: data-cy="bookTicket_12345"
            btn = page.locator("[data-cy^='bookTicket_']").first
            if await btn.count() == 0:
                logger.warning(f"⚠️ No 'bookTicket' buttons found on deep link page! (Sold Out?)")
                return None
            
            data_cy = await btn.get_attribute("data-cy")
            if not data_cy: return None
            
            # Extract "12345" from "bookTicket_12345"
            dynamic_id = data_cy.split("_")[1]
            logger.info(f"🔐 Resolved Dynamic ID for {tag}: {dynamic_id}")
            return dynamic_id

        except Exception as e:
            logger.error(f"❌ Failed to Resolve Dynamic ID: {e}")
            return None

    async def _worker_task(self, worker_id, browser, proxy_str, dates_chunk, ticket_type, language="ENG"):
        """
        Runs a solitary 'Virtual User' inside the provided browser.
        NOW SUPPORTS DYNAMIC SESSION IDs.
        """
        logger.info(f"🐛 [Worker {worker_id}] DEBUG: Worker Task V4 (Dynamic). TicketType: {ticket_type} Lang: {language}")
        
        # 1. PARSE PROXY
        proxy_config = None
        try:
            if proxy_str:
                if "@" in proxy_str:
                    # Generic user:pass@ip:port
                    user_pass, ip_port = proxy_str.split("@")
                    user, pwd = user_pass.split(":")
                    proxy_config = {"server": f"http://{ip_port}", "username": user, "password": pwd}
                elif "oxylabs" in proxy_str and os.getenv('OXYLABS_USERNAME'):
                    # Oxylabs Env Fallback
                    user = os.getenv('OXYLABS_USERNAME')
                    pwd = os.getenv('OXYLABS_PASSWORD')
                    proxy_config = {"server": f"http://{proxy_str}", "username": user, "password": pwd}
                else:
                    # IP:Port or IP:Port:User:Pass
                    parts = proxy_str.split(':')
                    if len(parts) == 4:
                        proxy_config = {"server": f"http://{parts[0]}:{parts[1]}", "username": parts[2], "password": parts[3]}
                    else:
                        proxy_config = {"server": f"http://{proxy_str}"}
        except Exception as e:
            logger.error(f"❌ [Worker {worker_id}] Proxy Parse Error: {e}")
            return []

        context = None
        page = None
        results = []

        try:
            # 2. CREATE CONTEXT
            try:
                context = await browser.new_context(
                    proxy=proxy_config,
                    user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
                    locale="it-IT",
                    timezone_id="Europe/Rome",
                    ignore_https_errors=True
                )
            except Exception as e:
                logger.error(f"❌ [Worker {worker_id}] Context Creation Failed: {e}")
                return []
            
            # 3. CREATE PAGE
            page = await context.new_page()
            if not page:
                 logger.error(f"❌ [Worker {worker_id}] Failed to create Page object!")
                 if context: await context.close()
                 return []
            
            # Apply Stealth
            await self.apply_stealth(context, page)

            # 4. RESOURCE BLOCKING (Aggressive)
            await page.route("**/*", lambda route: route.abort() 
                if route.request.resource_type in ["image", "media", "font", "stylesheet"] 
                else route.continue_())

            # 5. DYNAMIC SESSION INITIALIZATION (The "Warmup" + "ID Sniff")
            # We use the FIRST date in the chunk to establish the session.
            # Assumption: The Session ID works for subsequent fetches in the same context.
            if not dates_chunk:
                return []
                
            prime_date = dates_chunk[0]
            
            # FIX 2: Properly format date for timestamp calc if needed (dd/mm/yyyy)
            # The get_vatican_timestamp helper handles both formats.
            
            # RESOLVE ID
            visit_type_id = await self.resolve_dynamic_id(page, ticket_type, prime_date)
            
            if not visit_type_id:
                logger.warning(f"⚠️ [Worker {worker_id}] Could not resolve Dynamic ID. Aborting chunk.")
                await context.close()
                return []
            
            # 6. THE FETCH LOOP (Using Verified Dynamic ID)
            for date in dates_chunk:
                # Resolve Languages (User Request: Guided -> e.g. FRA)
                # Standard (0) -> visitLang=""
                # Guided (1) -> visitLang=CODE (from argument)
                loop_langs = []
                if ticket_type == 0:
                     loop_langs = [""] 
                else:
                    if language and language.upper() not in ["ALL", "ANY"]:
                         loop_langs = [language.upper()] 
                    else:
                         loop_langs = LANGUAGES

                # FIX: API EXPECTS dd/MM/yyyy
                api_date = date
                if "-" in date and not "/" in date:
                    y, m, d = date.split("-")
                    api_date = f"{d}/{m}/{y}"
                
                for lang_code in loop_langs:
                    lang_param = f"&visitLang={lang_code}" if lang_code else ""
                    
                    # USER REQUEST: "check the visittypedate and then call the api"
                    # We are using the resolved `visit_type_id` here.
                    
                    js_code = f"""
                    async () => {{
                        try {{
                            const url = "https://tickets.museivaticani.va/api/visit/timeavail?lang=it{lang_param}&visitTypeId={visit_type_id}&visitorNum=1&visitDate={api_date}";
                            const response = await fetch(url, {{
                                "headers": {{ "x-requested-with": "XMLHttpRequest" }}
                            }});
                            if (response.status !== 200) return {{ "error": "HTTP " + response.status }};
                            return await response.json();
                        }} catch (e) {{ return {{ "error": e.toString() }}; }}
                    }}
                    """
                    
                    try:
                        data = await page.evaluate(js_code)
                        
                        if "timetable" in data:
                             slots = [t['time'] for t in data['timetable'] if t['availability'] != 'SOLD_OUT']
                             if slots:
                                 logger.info(f"🎯 [Worker {worker_id}] HIT {api_date} ({lang_code}): {slots}")
                                 results.append({
                                     "date": date, 
                                     "type": "standard" if ticket_type == 0 else "guided",
                                     "language": lang_code,
                                     "slots": slots
                                 })
                        elif "error" in data:
                             # logger.debug(f"API Error: {data['error']}")
                             pass
                             
                    except Exception as e:
                        logger.warning(f"⚠️ [Worker {worker_id}] Fetch failed: {e}")
                    
                    await asyncio.sleep(0.1)

            await context.close()
            return results

        except Exception as e:
            logger.error(f"💥 [Worker {worker_id}] CRASHED: {e}")
            import traceback
            traceback.print_exc()
            if context: await context.close()
            return []

    async def run_once(self, ticket_type=0, language="ENG"):
        """
        Executes a PARALLEL TURBO pass.
        Launches 1 Browser, then N Contexts (Workers).
        Shards dates among available proxies.
        """
        results_map = {} # Maps date -> status
        
        # If no proxies, we can't do sharding effectively, but we try with 1
        worker_proxies = self.proxies if self.proxies else [None]
        
        async with async_playwright() as p:
            # 1. Launch One Heavy Browser
            browser = await p.chromium.launch(
                headless=True,
                args=[
                    "--no-sandbox",
                    "--disable-blink-features=AutomationControlled",
                    "--disable-infobars",
                    "--hide-scrollbars",
                    "--disable-dev-shm-usage" # RAM optimization
                ]
            )
            
            logger.info(f"🚀 [TURBO] Browser Launched. Spawning Workers for {len(self.target_dates)} dates...")
            
            try:
                # 2. Assign Dates to Proxies (Sharding)
                tasks = []
                # Cap max workers to avoid overload
                max_workers = 10
                actual_workers = min(len(worker_proxies), max_workers, len(self.target_dates))
                if actual_workers < 1: actual_workers = 1
                
                # Round Robin distribution
                chunks = [[] for _ in range(actual_workers)]
                for i, date in enumerate(self.target_dates):
                    chunks[i % actual_workers].append(date)
                    
                for i in range(actual_workers):
                    if not chunks[i]: continue
                    proxy = worker_proxies[i % len(worker_proxies)]
                    # Spawn Worker
                    tasks.append(self._worker_task(i, browser, proxy, chunks[i], ticket_type, language))
                    
                logger.info(f"⚡ Launching {len(tasks)} Parallel Workers...")
                
                # 3. Gather Results
                worker_results = await asyncio.gather(*tasks)
                
                # 4. Aggregate
                for date in self.target_dates:
                    results_map[date] = [] 
                    
                found_any = False
                for w_res in worker_results:
                    for item in w_res:
                        d = item['date']
                        slots = item['slots']
                        # formatted_slots = [{"time": t, "availability": "AVAILABLE"} for t in slots]
                        # FIX: tasks.py expects list of strings, not dicts
                        
                        if d in results_map:
                            results_map[d].extend(slots)
                        else:
                            results_map[d] = slots
                        
                        if slots: found_any = True

                logger.info(f"🏁 Turbo Cycle Complete. Found Availability: {found_any}")
                return results_map

            except Exception as e:
                logger.error(f"Single Pass Failed: {e}")
                import traceback
                traceback.print_exc()
                return {"error": str(e)}
            finally:
                if browser: await browser.close()

    async def run_hydra_cycle(self):
        """Main loop for the bot (Persistent Monitoring with Rotation)"""
        logger.info(f"🐉 HYDRA STARTING | Monitoring {len(self.target_dates)} dates")
        
        while True:
            # 1. Pick a Proxy for this session
            proxy_config = self.get_random_proxy()
            proxy_display = proxy_config['server'] if proxy_config else "DIRECT"
            logger.info(f"� ROTATION: New Session with Proxy: {proxy_display}")

            try:
                async with async_playwright() as p:
                    browser = await p.chromium.launch(
                        headless=True,
                        proxy=proxy_config,
                        args=[
                            "--no-sandbox",
                            "--disable-blink-features=AutomationControlled",
                            "--disable-infobars",
                            "--hide-scrollbars", 
                            "--disable-gpu", 
                        ]
                    )

                    context = await browser.new_context(
                        locale="it-IT",
                        timezone_id="Europe/Rome",
                        user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
                    )

                    page = await context.new_page()
                    await self.apply_stealth(context, page)

                    logger.info("⏳ Warming Session...")
                    # Targeted Warming
                    try:
                        await page.goto(f"https://tickets.museivaticani.va/home/details/{STANDARD_TICKET_ID}", timeout=60000, wait_until="domcontentloaded")
                    except:
                        logger.warning("Targeted warming timeout, proceeding anyway...")

                    # Run for X cycles before rotating proxy to avoid detection patterns
                    # If we just do 1 loop, it's very safe but higher overhead.
                    # Let's do 5 loops (approx 2-3 mins) then rotate.
                    CYCLES_PER_SESSION = 5
                    
                    for i in range(CYCLES_PER_SESSION):
                        logger.info(f"📍 Cycle {i+1}/{CYCLES_PER_SESSION} for this session")
                        
                        start_time = asyncio.get_event_loop().time()
                        
                        for date in self.target_dates:
                            # 1. Check Standard Ticket (UI LOGIC)
                            std_results = await self.check_standard_ticket_ui(page, date)
                            await self.process_results("STD-UI", date, std_results)
                            
                            # 2. Check Guided Tours (API NINJA LOGIC)
                            tasks = []
                            resolved_id = GUIDED_TOUR_ID 
                            for lang in LANGUAGES:
                                tasks.append(self.fetch_api_ninja(page, resolved_id, date, lang))
                            
                            guided_results = await asyncio.gather(*tasks)
                            for i, lang in enumerate(LANGUAGES):
                                await self.process_results(f"GUIDED-{lang}", date, guided_results[i])
                                
                            await asyncio.sleep(1) # Gap between dates

                        elapsed = asyncio.get_event_loop().time() - start_time
                        logger.info(f"💤 Cycle processed in {elapsed:.2f}s. Resting...")
                        await asyncio.sleep(random.uniform(20, 40))

                    logger.info("♻️ Session Finished. Rotating Proxy...")
                    await browser.close()
            
            except Exception as e:
                 logger.error(f"💥 Critical Error in Session: {e}. Restarting session immediately.")
                 await asyncio.sleep(5) # Brief pause before retry


if __name__ == "__main__":
    bot = HydraBot(use_proxies=True)
    asyncio.run(bot.run_hydra_cycle())
