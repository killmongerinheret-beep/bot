import logging
import json
import os
import random
import requests as py_requests
from datetime import timedelta
from celery import shared_task
from django.utils import timezone
from django.core.cache import cache
from django.db import models
from .models import MonitorTask, CheckResult, Agency, Proxy, SiteCredential

# 1. Clean Imports
try:
    from worker_vatican.monitor import VaticanPro
    from worker_colosseum.monitor import ColosseumPro
    from worker_vatican.hydra_monitor import HydraBot
except ImportError:
    from worker_vatican.monitor import VaticanPro
    from worker_colosseum.monitor import ColosseumPro
    from worker_vatican.hydra_monitor import HydraBot

logger = logging.getLogger(__name__)

def get_proxy_str(site='vatican'):
    """Helper to select the best proxy using Smart Reputation Logic"""
    now = timezone.now()
    
    # Reset expired cooldowns (clean up logic, or just filter)
    # Filter proxies that are active AND not cooling down
    valid_proxies = Proxy.objects.filter(is_active=True).filter(
        models.Q(cooldown_until__isnull=True) | models.Q(cooldown_until__lte=now)
    )
    
    if site == 'colosseum':
        # Colosseum needs high-quality IPs (ISP/Resid)
        proxy_obj = valid_proxies.filter(ip_port__icontains='oxylabs').order_by('?').first()
    else:
        # Vatican is less strict, but still prefer Oxylabs
        proxy_obj = valid_proxies.filter(ip_port__icontains='oxylabs').order_by('?').first()
        if not proxy_obj:
            proxy_obj = valid_proxies.order_by('?').first()

    if not proxy_obj:
        # If ALL proxies are on cooldown, pick the one with the earliest cooldown expiry
        # This prevents 100% downtime if everything is banned
        emergency_proxy = Proxy.objects.filter(is_active=True).order_by('cooldown_until').first()
        if emergency_proxy:
            logger.warning(f"⚠️ All proxies on cooldown! Using earliest available: {emergency_proxy} (Expires: {emergency_proxy.cooldown_until})")
            proxy_obj = emergency_proxy
        else:
            return None, None

    # Update Last Used
    proxy_obj.last_used = now
    proxy_obj.save(update_fields=['last_used'])

    user = proxy_obj.username
    if 'oxylabs' in proxy_obj.ip_port.lower():
        session_id = random.randint(10000, 99999)
        user = f"{proxy_obj.username}-session-{session_id}"
    
    if user and proxy_obj.password:
        return f"http://{user}:{proxy_obj.password}@{proxy_obj.ip_port}", proxy_obj
    else:
        return f"http://{proxy_obj.ip_port}", proxy_obj

def report_proxy_status(proxy_obj, success=True):
    """Update proxy reputation based on result"""
    if not proxy_obj: 
        return
        
    if success:
        if proxy_obj.fail_count > 0:
            proxy_obj.fail_count = 0
            proxy_obj.consecutive_failures = 0
            proxy_obj.cooldown_until = None
            proxy_obj.save()
    else:
        proxy_obj.fail_count += 1
        proxy_obj.consecutive_failures += 1
        
        # Smart Cooldown Logic (Exponential Backoff)
        # 1 fail = 0m, 3 fails = 5m, 5 fails = 30m, 10 fails = 2h
        cooldown_mins = 0
        if proxy_obj.consecutive_failures >= 3:
            cooldown_mins = 5
        if proxy_obj.consecutive_failures >= 5:
            cooldown_mins = 30
        if proxy_obj.consecutive_failures >= 10:
            cooldown_mins = 120
            
        if cooldown_mins > 0:
            proxy_obj.cooldown_until = timezone.now() + timedelta(minutes=cooldown_mins)
            logger.warning(f"🚫 Proxy {proxy_obj} cooling down for {cooldown_mins}m (Failures: {proxy_obj.consecutive_failures})")
            
        proxy_obj.save()

# --- GOD TIER: SESSION MANAGERS ---
@shared_task(name="refresh_colosseum_session", queue="colosseum")
def refresh_colosseum_session():
    """Runs periodically to pre-warm Colosseum cookies and store in Redis"""
    logger.info("🔄 GOD TIER: Refreshing Colosseum Session...")
    try:
        proxy_str, _ = get_proxy_str('colosseum')
        monitor = ColosseumPro(proxy=proxy_str)
        
        # 1. Try Direct API (Bypass Queue)
        # Using a distant date to check access (May 2026)
        monitor.get_availability(2026, 5)
        
        # 2. If API set cookies (e.g. incap/visid), cache them
        if monitor.session.cookies:
            cookies = monitor.session.cookies.get_dict()
            cache.set('colosseum_cookies', cookies, timeout=600)
            logger.info(f"✅ Colosseum Session Cached! ({len(cookies)} cookies)")
            return "Session Refreshed"
        else:
             # Even if no cookies, if API worked (no exception), we are good. 
             # But we can't cache 'nothing', so monitor will default to Direct API anyway.
             return "Verified API Access (No Cookies)"
    except Exception as e:
        logger.error(f"Failed to refresh Colosseum session: {e}")
    return "Failed"

@shared_task(name="refresh_vatican_session", queue="vatican")
def refresh_vatican_session():
    """Runs periodically to pre-warm Vatican cookies and store in Redis"""
    logger.info("🔄 GOD TIER: Refreshing Vatican Session...")
    try:
        proxy_str, _ = get_proxy_str('vatican')
        
        # Check for ANY active credential to use for warming (can use first found)
        creds = SiteCredential.objects.filter(site='vatican', is_active=True).first()
        username = creds.username if creds else None
        password = creds.password if creds else None
        
        monitor = VaticanPro(proxy=proxy_str, username=username, password=password)
        # Force generation
        monitor.generate_trust_cookies()
        
        if monitor.session.cookies:
            cookies = monitor.session.cookies.get_dict()
            cache.set('vatican_cookies', cookies, timeout=600)
            logger.info(f"✅ Vatican Session Cached! ({len(cookies)} cookies)")
            return "Session Refreshed"
    except Exception as e:
        logger.error(f"Failed to refresh Vatican session: {e}")
    return "Failed"


@shared_task(name="run_shared_vatican_monitor", queue="vatican")
def run_shared_vatican_monitor(ticket_type, language, dates):
    """
    OPTIMIZED: Checks a list of dates for a specific configuration
    and updates ALL matching tasks in the database.
    """
    try:
        # Use HydraBot for check
        bot = HydraBot(use_proxies=True)
        bot.target_dates = dates
        
        logger.info(f"🐉 HYDRA SHARED: Checking {len(dates)} dates (Type: {ticket_type}, Lang: {language})")
        
        # Determine language for bot
        bot_lang = language if ticket_type == 1 else "ENG" 
        
        import asyncio
        results = asyncio.run(bot.run_once(ticket_type=ticket_type, language=bot_lang))
        
        # Process Results & Update Tasks
        # We need to find ALL tasks that are:
        # 1. Active
        # 2. Match ticket_type
        # 3. Match language (if guided)
        # 4. Contain one of the dates checked
        
        # Aggregate updates per task to send ONE notification
        task_updates = {} # TaskId -> { task_obj, dates_found: {date: slots} }
        
        for date_str, slots in results.items():
            # Standardize status
            status = 'sold_out'
            if isinstance(slots, list) and len(slots) > 0:
                status = 'available'
            elif isinstance(slots, dict) and "error" in slots:
                status = 'error'
            
            # Find matching tasks
            matching_tasks = MonitorTask.objects.filter(
                site='vatican', 
                ticket_type=ticket_type,
                is_active=True,
                dates__icontains=date_str 
            )
            
            if ticket_type == 1:
                matching_tasks = matching_tasks.filter(language__iexact=language)
            
            logger.info(f"📝 Found {matching_tasks.count()} tasks for {date_str}...")
            
            for task in matching_tasks:
                if task.id not in task_updates:
                    task_updates[task.id] = {
                        'task': task,
                        'updates': {}
                    }
                
                task.last_checked = timezone.now()
                
                # If we found slots, update status to available.
                # If ALL monitored dates are sold out, status is sold_out.
                # But shared monitor only checks *some* dates.
                # So we update the status for *this specific check*.
                if status == 'available':
                    task.last_status = 'available'
                
                # Just store for notification logic
                task_updates[task.id]['updates'][date_str] = slots
                
                # Save Result Record
                if status == 'available' or task.last_status != 'available': 
                    # Only save interesting results or status changes to disable spam
                     CheckResult.objects.create(
                        task=task,
                        status=status,
                        details={date_str: slots},
                        error_message=slots.get("error") if isinstance(slots, dict) else None
                    )
                task.save()

        # Send Notifications for each Task
        for tid, data in task_updates.items():
            task = data['task']
            updates = data['updates'] # Map: date -> slots
            
            # Check if ANY available slots found
            found_any = False
            for d, s in updates.items():
                if isinstance(s, list) and len(s) > 0:
                    found_any = True
                    break
            
            # SPAM PREVENTION LOGIC
            # We sort keys and hash the content to see if it EXACTLY matches the last notification
            current_hash = "none"
            try:
                import hashlib
                # Create a canonical string representation of updates
                # e.g. "2026-05-25:09:00,09:30|2026-05-26:10:00"
                # Sort dates
                sorted_dates = sorted(updates.keys())
                content_str = ""
                for d in sorted_dates:
                    slots = updates[d]
                    if isinstance(slots, list):
                        sorted_slots = sorted(slots)
                        content_str += f"{d}:{','.join(sorted_slots)}|"
                
                # Create MD5 of this content
                current_hash = hashlib.md5(content_str.encode()).hexdigest()
                
                # Check against last stored hash (we need a place to store it)
                # We can store it in 'last_result_summary' or a new field.
                # Since 'last_result_summary' is JSON, we can add a field there.
                
                prev_summary = {}
                if task.last_result_summary:
                    try:
                        prev_summary = json.loads(task.last_result_summary)
                    except:
                        pass
                
                last_notified_hash = prev_summary.get('_notified_hash')
                
                # If exact duplicate of what we LAST NOTIFIED, skip (unless 'always' mode?)
                # User complaint: "bot is spamming". So we SKIP.
                # Only if found_any is True (we don't spam 'sold_out' anyway usually)
                if found_any and current_hash == last_notified_hash:
                    logger.info(f"🔕 Skipping duplicate notification for Task {task.id} (Hash match)")
                    
                    # Even if we skip, we should probably update the summary with latest time?
                    # But if we update summary, we MUST keep the hash.
                    prev_summary['last_updated'] = str(timezone.now())
                    task.last_result_summary = json.dumps(prev_summary)
                    task.save(update_fields=['last_result_summary'])
                    continue
                
                # Update hash in DB (even if we don't notify below, we should track state)
                # But typically we update it AFTER sending notification.
            except Exception as e:
                logger.error(f"Hash calc failed: {e}")
                current_hash = "error"
            
            if found_any and task.notification_mode != 'silent':
                # Build Message
                msg = f"⛪ *VATICAN FOUND!* ({task.area_name})\n"
                
                # Helper for Link Generation
                def get_vatican_link(d_str, t_type):
                     try:
                         from zoneinfo import ZoneInfo
                         from datetime import datetime
                         rome = ZoneInfo("Europe/Rome")
                         if "/" in d_str:
                             dt = datetime.strptime(d_str, "%d/%m/%Y")
                         else:
                             dt = datetime.strptime(d_str, "%Y-%m-%d")
                         midnight = dt.replace(hour=0, minute=0, second=0, microsecond=0, tzinfo=rome)
                         ts = int(midnight.timestamp() * 1000)
                         tag = "MV-Biglietti" if t_type == 0 else "MV-Visite-Guidate"
                         return f"https://tickets.museivaticani.va/home/fromtag/1/{ts}/{tag}/1"
                     except:
                         return "https://tickets.museivaticani.va/"

                user_prefs = task.preferred_times or []
                
                for date, slots in updates.items():
                    # Only show if slots exist
                    if isinstance(slots, list) and slots:
                         link = get_vatican_link(date, task.ticket_type)
                         
                         # HIGHLIGHT LOGIC
                         formatted_slots = []
                         
                         # Sort slots for consistency
                         slots.sort()
                         
                         for s in slots:
                             # Check if slot starts with preferred time (e.g. "09:00")
                             is_pref = False
                             for p in user_prefs:
                                 if s.startswith(p):
                                     is_pref = True
                                     break
                             
                             if is_pref:
                                 formatted_slots.append(f"*{s}*") # Bold
                             else:
                                 formatted_slots.append(s)
                                 
                         # Brief: limit to 25 slots, basically show all reasonable amounts
                         slot_str = ", ".join(formatted_slots[:25])
                         if len(formatted_slots) > 25: slot_str += "..."
                         
                         msg += f"\n📅 *{date}*: {len(slots)} slots available\n"
                         msg += f"⏰ {slot_str}\n"
                         msg += f"🔗 [Book Now]({link})\n"
                
                send_telegram_signal(task.agency.telegram_chat_id, msg)
                
            # Update Summary with NEW Hash and Content (Always, if found_any)
            # This ensures dashboard shows latest info AND hash is saved for next comparison.
            if found_any:
                try:
                     summary_data = {
                         "updates": updates,
                         "_notified_hash": current_hash,
                         "last_updated": str(timezone.now())
                     }
                     task.last_result_summary = json.dumps(summary_data)
                     task.save(update_fields=['last_result_summary'])
                except Exception as e:
                    logger.error(f"Failed to save summary: {e}")

        return f"Shared Check Completed and Notified for {len(dates)} dates"

    except Exception as e:
        logger.error(f"Error in run_shared_vatican_monitor: {e}")
        return str(e)

def send_telegram_signal(chat_id, message):
    TOKEN = os.getenv("TELEGRAM_BOT_TOKEN") 
    if not TOKEN:
        logger.error("No TELEGRAM_BOT_TOKEN configured")
        return
    url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
    try:
        py_requests.post(url, json={"chat_id": chat_id, "text": message}, timeout=10)
        logger.info(f"Telegram signal sent to {chat_id}")
    except Exception as e:
        logger.error(f"Failed to send Telegram signal: {e}")

@shared_task(name="run_colosseum_monitor", queue="colosseum")
def run_colosseum_monitor(task_id):
    try:
        task = MonitorTask.objects.get(id=task_id)
        agency = task.agency
        
        proxy_str, proxy_obj = get_proxy_str('colosseum')
        
        monitor = ColosseumPro(lang=task.language, proxy=proxy_str)
        if task.area_name and len(task.area_name) == 36:
            monitor.event_guid = task.area_name
        
        logger.info(f"Running Colosseum Pro check for Task {task_id} using proxy {proxy_obj}")
        
        results = monitor.check_dates(task.dates)
        
        prev_status = task.last_status
        status = 'available' if results else 'sold_out'
        CheckResult.objects.create(
            task=task,
            status=status,
            details=results
        )
        
        task.last_checked = timezone.now()
        task.last_status = status
        task.last_result_summary = json.dumps(results)
        task.save()
        
        # Report Success
        report_proxy_status(proxy_obj, success=True)
        
        if (status == 'available' and prev_status != 'available') or (task.notification_mode == 'any_change' and status != prev_status):
            if task.notification_mode != 'silent':
                send_telegram_signal(agency.telegram_chat_id, f"🏛️ COLOSSEUM ALERT: {task.area_name}\n\n" + json.dumps(results, indent=2))
        
        return f"Colosseum check completed for task {task_id}. Status: {status}"
        
    except Exception as e:
        # Report Failure
        report_proxy_status(proxy_obj, success=False)
        
        logger.error(f"Error in run_colosseum_monitor: {e}")
        try:
            task = MonitorTask.objects.get(id=task_id)
            task.last_status = 'error'
            task.last_result_summary = f"Engine Error: {str(e)}"
            task.save()
        except:
            pass
        return str(e)

@shared_task(name="orchestrate_all_tasks")
def orchestrate_all_tasks():
    """
    OPTIMIZED: Groups tasks by configuration and dispatches SHARED checks.
    """
    now = timezone.now()
    active_tasks = MonitorTask.objects.filter(is_active=True)
    
    # 1. Grouping Structure
    # Key: (ticket_type, language) -> Set of Dates
    groups = {} 
    
    colosseum_count = 0
    
    for task in active_tasks:
        # User defined interval or default 120s (Optimized)
        interval_seconds = getattr(task, 'check_interval', 120)
        if not interval_seconds or interval_seconds < 60:
            interval_seconds = 60 # Force min 60s
            
        should_run = False
        if not task.last_checked:
            should_run = True
        else:
            elapsed = (now - task.last_checked).total_seconds()
            if elapsed >= interval_seconds:
                should_run = True
                
        if should_run:
            if task.site == 'vatican' and task.dates:
                key = (task.ticket_type, task.language or 'ENG')
                if key not in groups: groups[key] = set()
                for d in task.dates:
                    groups[key].add(d)
            elif task.site == 'colosseum':
                 # Keep existing per-task logic for Colosseum (It is lightweight API)
                 run_colosseum_monitor.apply_async(args=[task.id], countdown=random.randint(5, 30))
                 colosseum_count += 1
                
    # 2. Dispatch Shared Tasks
    count = 0
    for (t_type, lang), date_set in groups.items():
        if not date_set: continue
        
        # Chunk dates to avoid overload (max 10 dates per worker)
        all_dates = list(date_set)
        CHUNK_SIZE = 10
        
        for i in range(0, len(all_dates), CHUNK_SIZE):
            chunk = all_dates[i:i + CHUNK_SIZE]
            
            # Jitter for anti-ban
            jitter = random.randint(5, 30)
            
            run_shared_vatican_monitor.apply_async(
                args=[t_type, lang, chunk],
                countdown=jitter
            )
            count += len(chunk)

    return f"Queued Checks for {count} unique dates across {len(active_tasks)} tasks."
@shared_task(name="cleanup_old_results")
def cleanup_old_results():
    """
    Delete CheckResult records older than 7 days to save space.
    Runs daily via Celery Beat.
    """
    days_to_keep = 7
    cutoff_date = timezone.now() - timedelta(days=days_to_keep)
    
    deleted_count, _ = CheckResult.objects.filter(check_time__lt=cutoff_date).delete()
    
    logger.info(f"🧹 Cleanup: Deleted {deleted_count} results older than {days_to_keep} days.")
    return f"Deleted {deleted_count} old results"

@shared_task(name="cleanup_expired_monitor_tasks")
def cleanup_expired_monitor_tasks():
    """
    Daily Cleanup: Removes dates from the past.
    If a task has no future dates, it is deleted.
    """
    from datetime import datetime
    now_date = timezone.now().date()
    
    tasks = MonitorTask.objects.all()
    cleaned_count = 0
    deleted_count = 0
    
    for task in tasks:
        if not task.dates:
            continue
            
        # Filter dates
        new_dates = []
        changed = False
        
        for d_str in task.dates:
            try:
                # Handle formats
                if "/" in d_str:
                    dt = datetime.strptime(d_str, "%d/%m/%Y").date()
                elif "-" in d_str:
                    dt = datetime.strptime(d_str, "%Y-%m-%d").date()
                else:
                    # Keep invalid formats just in case, or drop?
                    # Let's drop them if we are strict, but maybe better to keep to avoid accidental deletion
                    # Actually, if we can't parse it, we can't check if it's past.
                    # Let's assume valid formats.
                    continue 
                
                if dt >= now_date:
                    new_dates.append(d_str)
                else:
                    changed = True
            except:
                pass 
                
        if changed:
            if not new_dates:
                logger.info(f"🗑️ Task {task.id} has no future dates. Deleting.")
                task.delete()
                deleted_count += 1
            else:
                task.dates = new_dates
                task.save()
                cleaned_count += 1
                
    return f"Cleanup: Updated {cleaned_count} tasks, Deleted {deleted_count} tasks."
