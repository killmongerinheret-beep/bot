from rest_framework import viewsets, permissions, status
from rest_framework.views import APIView
from rest_framework.response import Response
from .models import Agency, MonitorTask, CheckResult, Proxy, SiteCredential
from .serializers import (
    AgencySerializer, MonitorTaskSerializer, CheckResultSerializer,
    ProxySerializer, SiteCredentialSerializer
)

class AgencyViewSet(viewsets.ModelViewSet):
    queryset = Agency.objects.all()
    serializer_class = AgencySerializer
    permission_classes = [permissions.AllowAny]

class MonitorTaskViewSet(viewsets.ModelViewSet):
    serializer_class = MonitorTaskSerializer
    permission_classes = [permissions.AllowAny]

    def get_queryset(self):
        queryset = MonitorTask.objects.all()
        agency_id = self.request.query_params.get('agency_id')
        if agency_id:
            queryset = queryset.filter(agency_id=agency_id)
        return queryset

    def perform_create(self, serializer):
        agency = serializer.validated_data['agency']
        plan = getattr(agency, 'plan', 'free')
        active_task_count = MonitorTask.objects.filter(agency=agency, is_active=True).count()
        
        limits = {
            'free': 2,
            'pro': 20,
            'agency': 500
        }
        limit = limits.get(plan, 2)
        
        if active_task_count >= limit:
            from rest_framework.exceptions import ValidationError
            raise ValidationError({'detail': f"Monitor limit reached for your '{plan}' plan ({limit} tasks). Please upgrade."})
            
        serializer.save()

class CheckResultViewSet(viewsets.ModelViewSet):
    serializer_class = CheckResultSerializer
    permission_classes = [permissions.AllowAny]

    def get_queryset(self):
        queryset = CheckResult.objects.all().order_by('-check_time')
        agency_id = self.request.query_params.get('agency_id')
        task_id = self.request.query_params.get('task')
        
        if task_id:
            queryset = queryset.filter(task_id=task_id)
        if agency_id:
            queryset = queryset.filter(task__agency_id=agency_id)
        return queryset

class ProxyViewSet(viewsets.ModelViewSet):
    queryset = Proxy.objects.all()
    serializer_class = ProxySerializer
    permission_classes = [permissions.AllowAny]

class SiteCredentialViewSet(viewsets.ModelViewSet):
    queryset = SiteCredential.objects.all()
    serializer_class = SiteCredentialSerializer
    permission_classes = [permissions.AllowAny]

class AgencyLoginView(APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        name = request.data.get('name')
        api_key = request.data.get('api_key')
        
        if not name or not api_key:
            return Response({'error': 'Name and API Key search required'}, status=status.HTTP_400_BAD_REQUEST)
            
        agency = Agency.objects.filter(name=name, api_key=api_key).order_by('id').first()
        
        if not agency:
            return Response({'error': 'Invalid credentials'}, status=status.HTTP_401_UNAUTHORIZED)
            
        if not agency.is_active:
            return Response({'error': 'Agency account is inactive'}, status=status.HTTP_403_FORBIDDEN)
            
        return Response({
            'id': agency.id,
            'name': agency.name,
            'chat_id': agency.telegram_chat_id
        })

class MyAgencyView(APIView):
    """
    Get or Create an Agency for the authenticated Clerk User.
    Expects 'owner_id' in request data.
    """
    permission_classes = [permissions.AllowAny] # In future, verify JWT

    def post(self, request):
        owner_id = request.data.get('owner_id')
        email = request.data.get('email', 'Unknown')
        
        if not owner_id:
            return Response({'error': 'owner_id required'}, status=status.HTTP_400_BAD_REQUEST)
            
        # Robust Get or Create to prevent Race Conditions
        import uuid
        defaults = {
            'name': f"Agency-{email.split('@')[0]}",
            'api_key': str(uuid.uuid4())[:8]
        }
        
        agency, created = Agency.objects.get_or_create(
            owner_id=owner_id,
            defaults=defaults
        )
            
        return Response({
            'id': agency.id,
            'name': agency.name,
            'api_key': agency.api_key,
            'chat_id': agency.telegram_chat_id
        })
